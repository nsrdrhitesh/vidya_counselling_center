<article class="quote-card"><span class="quote-mark" aria-hidden="true">“</span>
@if($review->rating)<span class="review-rating" aria-label="{{ $review->rating }} out of 5 stars">{{ str_repeat('★',$review->rating) }}{{ str_repeat('☆',5-$review->rating) }}</span>
@endif<blockquote>{{ $review->text }}</blockquote><p><strong>{{ $review->public_name }}</strong><small>{{ $review->source==='admin'?'Feedback recorded by the centre':'Website submission' }}</small>
@if($review->service?->isPublic())<small>{{ $review->service->name }}</small>
@endif</p></article>
