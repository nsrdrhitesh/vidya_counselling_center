
@extends('layouts.admin')
@section('title',$story->exists?'Edit Client Story':'Add Client Story')
@section('description','Curated experiences with recorded permission. No invented testimonials.')
@include('centre.editor-assets')
@section('actions')<a class="button" href="{{ route('stories.index') }}">All Stories</a>
@endsection
@section('content')
<form method="post" action="{{ $story->exists?route('stories.update',$story):route('stories.store') }}" class="form-columns" data-dirty>
@csrf 
@if($story->exists) 
@method('PUT') 
@endif<div><section class="card"><h2>Story</h2><x-centre-field name="title" label="Story title" :value="$story->title" required/><x-centre-field name="quotation" label="Authentic quotation" type="textarea" :value="$story->quotation" required hint="Preserve authentic spelling, including Counselling if it occurs in the original. Avoid clinical or identifying details."/>
@if($story->exists)<details><summary>Original quotation (immutable)</summary><blockquote>{{ $story->original_quotation }}</blockquote></details>
@endif<x-centre-field name="story_html" label="Supporting narrative" type="rich" :value="$story->story_html"/><x-centre-field name="anonymous" label="Public identity" type="select" :value="(int)$story->anonymous" :options="[1=>'Anonymous client',0=>'Named — requires identity consent']"/><x-centre-field name="display_name" label="Approved display name" :value="$story->display_name"/><x-centre-field name="service_id" label="Related service" type="select" :value="$story->service_id" :options="[''=>'None']+$services->pluck('name','id')->all()"/></section><section class="card"><h2>Private source & consent record</h2><p class="hint">Notes are encrypted and never public. Record a secure source reference; do not paste unnecessary clinical details.</p><x-centre-field name="source_type" label="Source type" type="select" :value="$story->source_type" :options="['written'=>'Written feedback','email'=>'Email','whatsapp'=>'WhatsApp','video'=>'Video reference','other'=>'Other']"/><x-centre-field name="received_at" label="Date received" type="date" :value="$story->received_at?->format('Y-m-d')"/><x-centre-field name="private_notes" label="Private source / permission reference" type="textarea" :value="$story->private_notes"/><x-centre-field name="consent_status" label="Publication consent" type="select" :value="$story->consent_status" :options="['pending'=>'Pending','approved'=>'Approved','withdrawn'=>'Withdrawn']"/><x-centre-field name="consented_at" label="Actual consent date/time (IST)" type="datetime-local" :value="$story->consented_at?->timezone('Asia/Kolkata')->format('Y-m-d\TH:i')"/>
@foreach(['identity_consent'=>'Explicit permission to publish this name','media_consent'=>'Explicit permission to publish this image','source_consent'=>'Explicit permission to identify the source'] as $key=>$label)<x-centre-field :name="$key" :label="$label" type="select" :value="(int)$story->$key" :options="[0=>'No',1=>'Yes — permission recorded']"/>
@endforeach</section></div><aside><section class="card"><h2>Visibility</h2><x-centre-field name="status" label="Status" type="select" :value="$story->status" :options="['draft'=>'Draft','published'=>'Published','archived'=>'Archived']"/><x-centre-field name="featured" label="Featured on homepage" type="select" :value="(int)$story->featured" :options="[0=>'No',1=>'Yes']"/><x-centre-field name="display_order" label="Display order" type="number" :value="$story->display_order??0" required/><button class="button primary">Save Client Story</button></section><section class="card"><h2>Consented media</h2>
@include('centre.media-picker',['mediaValue'=>$story->media_id])</section></aside></form>
@endsection
