
@extends('layouts.admin')
@section('title',$service->exists?'Edit Service':'Add Service')
@section('description','Structured service information, public visibility and search presentation.')
@include('centre.editor-assets')
@section('actions')<a class="button" href="{{ route('services-admin.index') }}">All Services</a>
@if($service->exists)<a class="button" href="{{ route('services-admin.show',$service) }}">Effective schema</a><a class="button" href="{{ route('services-admin.preview',$service) }}" target="_blank" rel="noopener">Private preview ↗</a>
@endif 
@endsection
@section('content')
<form method="post" action="{{ $service->exists?route('services-admin.update',$service):route('services-admin.store') }}" class="form-columns" data-dirty>
@csrf 
@if($service->exists) 
@method('PUT') 
@endif<input type="hidden" name="version" value="{{ $service->version }}"><div><section class="card"><h2>Service content</h2><x-centre-field name="name" label="Service name" :value="$service->name" required/><x-centre-field name="slug" label="URL slug" :value="$service->slug" hint="Lowercase English words joined by hyphens. Changes to published slugs keep a direct redirect; historical URLs stay reserved."/><x-centre-field name="summary" label="Card summary" type="textarea" :value="$service->summary"/><x-centre-field name="body_html" label="Detailed description" type="rich" :value="$service->body_html"/></section><section class="card"><h2>Structured service facts</h2><p class="hint">Add only actual centre facts. Keep one fact per row; order is preserved within each group.</p>
@php($rows=old('sections',$service->sections?->toArray()??[]))<div data-sections data-next="{{ count($rows) }}">
@foreach($rows as $i=>$row)
@include('centre.service-section',['index'=>$i,'row'=>$row])
@endforeach</div><template id="section-template">
@include('centre.service-section',['index'=>'__INDEX__','row'=>[]])</template><button type="button" class="button" data-add-section>Add a fact</button></section><section class="card"><h2>Search & sharing</h2>
@foreach(['seo_title'=>'SEO title','seo_description'=>'SEO description','canonical_url'=>'Canonical HTTPS URL','og_title'=>'Social title','og_description'=>'Social description','og_image'=>'Social image HTTPS URL'] as $key=>$label)<x-centre-field :name="$key" :label="$label" :value="$service->$key"/>
@endforeach<x-centre-field name="noindex" label="Search visibility" type="select" :value="(int)$service->noindex" :options="[0=>'Allow indexing',1=>'No index']"/><x-centre-field name="schema_mode" label="Service schema source" type="select" :value="$service->schema_mode" :options="['automatic'=>'Automatic — actual service fields','manual'=>'Manual — validated override']"/><x-centre-field name="manual_schema" label="Manual JSON-LD data" type="textarea" :value="$service->manual_schema" hint="Plain JSON, no script tags. One Service with matching name/canonical URL; at most one breadcrumb. Never include ratings, invented credentials or FAQ schema. Blank falls back to automatic."/></section></div><aside><section class="card"><h2>Publishing</h2><x-centre-field name="status" label="Status" type="select" :value="$service->status" :options="['draft'=>'Draft','published'=>'Published']"/><x-centre-field name="display_order" label="Display order" type="number" :value="$service->display_order??0" required/><x-centre-field name="featured" label="Featured" type="select" :value="(int)$service->featured" :options="[0=>'No',1=>'Yes']"/><x-centre-field name="cta_label" label="Button label" :value="$service->cta_label??'Request a Consultation'"/><x-centre-field name="duration" label="Verified session duration (optional)" :value="$service->duration"/><x-centre-field name="fees" label="Verified fees (optional)" :value="$service->fees"/><x-centre-field name="offer_verified" label="Fee/duration verification" type="select" :value="(int)$service->offer_verified" :options="[0=>'Not verified — keep fee/duration empty',1=>'Confirmed with centre']"/><button class="button primary">Save Service</button></section><section class="card"><h2>Service image</h2>
@include('centre.media-picker',['mediaValue'=>$service->media_id])</section></aside></form>
@endsection
