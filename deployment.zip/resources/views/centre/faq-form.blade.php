
@extends('layouts.admin')
@section('title',$faq->exists?'Edit FAQ':'Add FAQ')
@section('description','Write once, assign to stable public pages and set an order for each destination.')
@include('centre.editor-assets')
@section('actions')<a class="button" href="{{ route('faqs.index') }}">All FAQs</a>
@endsection
@section('content')
<form method="post" action="{{ $faq->exists?route('faqs.update',$faq):route('faqs.store') }}" class="form-columns" data-dirty>
@csrf 
@if($faq->exists) 
@method('PUT') 
@endif<div><section class="card"><x-centre-field name="question" label="Question" :value="$faq->question" required/><x-centre-field name="answer_html" label="Answer" type="rich" :value="$faq->answer_html"/><x-centre-field name="category" label="Editorial group / category" :value="$faq->category"/><x-centre-field name="editorial_notes" label="Private editorial notes" type="textarea" :value="$faq->editorial_notes"/></section><section class="card"><h2>Page assignments</h2><p class="hint">A shared FAQ appears only on eligible assigned pages. References survive service/post slug changes. Lower order values appear first.</p><label>Find a destination<input type="search" data-page-search placeholder="Search title, page type or path"></label><div class="assignment-chips" data-assignment-chips aria-label="Selected pages"></div>
@php($selected=array_map('intval',old('pages',$faq->exists?$faq->pages->pluck('id')->all():[])))<div class="page-picker" data-page-picker>
@foreach($pages->groupBy('kind') as $kind=>$group)<section data-page-group><h3>{{ ucfirst($kind) }} pages</h3>
@foreach($group as $page)<div class="page-option"><label><input type="checkbox" name="pages[]" value="{{ $page->id }}" data-title="{{ $page->title }}" 
@checked(in_array($page->id,$selected,true))><span>{{ $page->title }}<small class="muted"> · {{ $page->path }} · {{ $page->status }}</small></span></label><input type="number" name="orders[{{ $page->id }}]" min="0" max="10000" aria-label="Order on {{ $page->title }}" value="{{ old('orders.'.$page->id,$faq->exists?($faq->pages->firstWhere('id',$page->id)?->pivot->display_order??0):0) }}"></div>
@endforeach</section>
@endforeach</div></section></div><aside><section class="card"><h2>Publishing</h2><x-centre-field name="status" label="Status" type="select" :value="$faq->status" :options="['draft'=>'Draft','published'=>'Published']"/><x-centre-field name="schema_page_id" label="Canonical schema destination (optional)" type="select" :value="$faq->schema_page_id" :options="[''=>'No FAQ structured data']+$pages->mapWithKeys(fn($p)=>[$p->id=>ucfirst($p->kind).' · '.$p->title])->all()" hint="Must be an assigned page. Website-level opt-in is also required. No promise of Google FAQ rich results; never repeat FAQ schema across assigned pages."/><button class="button primary">Save FAQ & assignments</button></section></aside></form>
@endsection
