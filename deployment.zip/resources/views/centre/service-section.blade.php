<div class="section-row"><label>Group<select name="sections[{{ $index }}][kind]">
@foreach(['audience'=>'Audience','concerns'=>'Concerns supported','expect'=>'What to expect','modes'=>'Consultation modes'] as $v=>$text)<option value="{{ $v }}" 
@selected(($row['kind']??'audience')===$v)>{{ $text }}</option>
@endforeach</select></label><label>Heading (optional)<input name="sections[{{ $index }}][heading]" value="{{ $row['heading']??'' }}" maxlength="255"></label><label>Fact / description<textarea name="sections[{{ $index }}][content]" rows="2" required maxlength="1500">{{ $row['content']??'' }}</textarea></label><button type="button" class="button small remove-section">Remove fact</button></div>
